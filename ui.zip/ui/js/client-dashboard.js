console.log('in cdb control');

const ModalControl = require('./modal-control');

const modalControl = new ModalControl('create-acct');

console.log('after cdb control');